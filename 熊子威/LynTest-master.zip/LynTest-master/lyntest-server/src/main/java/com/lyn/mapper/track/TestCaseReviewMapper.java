package com.lyn.mapper.track;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.lyn.model.track.TestCaseReviewDO;
import org.springframework.stereotype.Repository;

/**
 * <p>
 *  Mapper 接口
 * </p>
 * @author 简单随风 - 自动生成代码
 * @since 2020-12-14
 */
@Repository
public interface TestCaseReviewMapper extends BaseMapper<TestCaseReviewDO> {

}
