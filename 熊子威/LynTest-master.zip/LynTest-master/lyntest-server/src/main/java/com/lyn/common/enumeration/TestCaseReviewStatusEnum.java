package com.lyn.common.enumeration;

/**
 * @author 简单随风
 * @date 2020/11/25
 */
public enum TestCaseReviewStatusEnum {
    Prepare, Underway, Completed
}
