package com.lyn.bo;

import lombok.Data;

/**
 * @author 简单随风
 * @date 2020/9/8
 */
@Data
public class CreatorBO {

    private String creatorName;

    private String creatorCode;
}
