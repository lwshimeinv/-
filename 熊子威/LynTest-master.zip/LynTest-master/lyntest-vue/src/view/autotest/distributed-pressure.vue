<template>
  <div>
    slave机待配置
    server端已集成AsyncRestTemplate，可进行远程异步化调用
    也可自行配置为WebCliennt
  </div>
</template>

<script>
export default {
  name: 'distributed-pressure'
}
</script>

<style scoped>

</style>
