const department = [{
  label: '上海嘉定区江桥营业部',
  value: 'W0113080102',
}, {
  label: '上海闵行区浦江镇营业部',
  value: 'W011302020515',
}, {
  label: '上海黄浦赛格营业部',
  value: 'W0113080203',
}, {
  label: '上海虹口营业部',
  value: 'W0113080202',
}, {
  label: '张家口涿鹿县营业部',
  value: 'W0000007301',
}, {
  label: '【H】张家口万全县营业部',
  value: 'W0000007233',
}, {
  label: '上海闵行区莘庄营业部',
  value: 'W011302020408',
}, {
  label: '上海徐汇区虹漕南路营业部',
  value: 'W040628220',
}, {
  label: '北京通州派送部',
  value: 'W011305080404',
}, {
  label: '上海枢纽中心',
  value: 'W3100020616',
}, {
  label: '北京转运场',
  value: 'W120003012205',
}, {
  label: '上海派送中心',
  value: 'W0113080403',
}]

export default {
  department,
}
